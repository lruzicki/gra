#include <stdio.h>
#include <stdlib.h>
int przyciskmenu=0,przyciskmenu2=0; //wybor menu
int dlugosczycia; //długość życia węża
char nic=' ';
void czysc()
{
    system("cls");
}
char menu[4]="MENU";
int main()
{   
    czysc();
    printf("   ---_ ......._-_--. \n");      
    printf("  (|\\ /      / /| \\  \\ \n");
    printf("  /  /     .'  -=-'   `. ");
            for(int i=0;i<4;i++)
            {
                if(i==0)
                    printf("%20c",menu[i]);
                else
                    printf("%c",menu[i]);
            }
    printf("\n");
    printf(" /  /    .'             ) \n");
    printf("_/  /   .'        _.)   / ");
            printf("%15c",nic);
                    printf("1. Graj\n");
    printf("/ o   o        _.-' /  .' \n");
    printf("\\          _.-'    / .'*| ");
            printf("%15c",nic);
                    printf("2. TABELA WYNIKOW\n");
    printf("\\______.-'//    .'.' \\*| \n");
    printf("\\|  \\ | //   .'.' _ |*| ");
            printf("%15c",nic);
                    printf("  3. WYJDZ\n");
    printf(" `   \\|//  .'.'_ _ _|*| \n");
    printf("  .  .// .'.' | _ _ \\*| \n");
    printf("  \\`-|\\_/ /   \\ \\ _ _ \\*\\ \n");
    printf("   `/'\\__/      \\ _ _ \\*\\ \n");
    printf("  /^|            \\ _ _ \\* \n");
    printf(" '  `             \\ _ _ \\  \n");
    printf("                   \\_ \n");
    scanf("%d",&przyciskmenu);

    while(przyciskmenu>=0 && przyciskmenu<4)
    {
        switch (przyciskmenu)
        {
        case 1: // MENU Z GRAMI
            czysc();
                printf("   ---_ ......._-_--. \n");      
            printf("  (|\\ /      / /| \\  \\ \n");
            printf("  /  /     .'  -=-'   `. ");
                    printf("%19c",nic);
                            printf("Wybierz gre w jaka chcesz zagrac! \n");            printf(" /  /    .'             ) \n");
            printf("_/  /   .'        _.)   / ");
                    printf("%15c",nic);
                            printf("  1. Texas Hold em\n");
            printf("/ o   o        _.-' /  .' \n");
            printf("\\          _.-'    / .'*| ");
                    printf("%15c",nic);
                            printf("  2. Clicker\n");
            printf("\\______.-'//    .'.' \\*| \n");
            printf("\\|  \\ | //   .'.' _ |*| \n");
            printf(" `   \\|//  .'.'_ _ _|*| \n");
            printf("  .  .// .'.' | _ _ \\*| \n");
            printf("  \\`-|\\_/ /   \\ \\ _ _ \\*\\ \n");
            printf("   `/'\\__/      \\ _ _ \\*\\ ");
                    printf("%15c",nic);
                            printf("  5. Cofnij do menu glownego\n");
            printf("  /^|            \\ _ _ \\* \n");
            printf(" '  `             \\ _ _ \\  \n");
            printf("                   \\_ \n");
            przyciskmenu=5;
            przyciskmenu2=1; // WARUNEK POWSTANIA NOWEGO SWITCHA
            break;
        case 2:
            czysc();
            printf("%19c",nic);
            printf("TOP 10 WYNIKÓW");
        case 3:
            return 0;
        default:
            scanf("%d",&przyciskmenu);
            break;
        }
        if(przyciskmenu2==1)
        {
            przyciskmenu2=0;
                while (przyciskmenu2>=0 && przyciskmenu2<5)
                {
                switch (przyciskmenu2)
                {
                case 1:
                    czysc();
                    printf("Grasz w Texas Hold em!\n\n");
                    printf("Jest to rodzaj pokera w ktorym otrzymujesz na start 2 karty tak jak inni uczestnicy.\nCo runde podbija sie stawke, trzeba wyrownac do gracza rozpoczynajacego lub przebic ja.\nPo turze dokladania pieniedzy wystawia sie kolejna karte na stol, az bedzie ich 5.\nPo odslonieciu wszystkich 5 kart jest ostatnia tura na obstawianie pieniedzy.\nZawsze mozna spasowac, traci sie wtedy jednak cala wystawiona kwote.\nNa koniec sprawdza sie karty, osoba ktora uzyskala specjalny patern \n lub najwyzsza pare kart wygrywa wszystkie pieniadze.\n");
                    przyciskmenu2=5;
                    break;
                case 2:
                    czysc();
                    printf("Grasz w Clickera!");
                    przyciskmenu2=5;
                    break;
                default:
                    scanf("%d",&przyciskmenu2);
                    break;
                }
            }
        }
    }
    return 0;
}