#include <stdio.h>

int w=0;
int a;
int serce=6;
char nic=' '; //do towrzenia odstepow tekstu, zeby nie robic stringow
void czysc()
{
    system("cls");
}

int licz()
{
    if(a==1)
        w=w+1;
    else if(a==2)
        w=w+2;
    return w;
}

void wazprawy()
{
    printf("%30c   __   \n",nic);
    printf("%30c  {0O}  \n",nic);
    printf("%30c  \\__/   \n",nic);
    printf("%30c  /^/  \n",nic);
    printf("%30c ( (  \n",nic);
    printf("%30c \\_\\_____  \n",nic);
    printf("%30c (_______)  \n",nic);
    printf("%30c(_________()Oo  \n",nic);
}
void wazlewy()
{
    printf("%30c          __   \n",nic);
    printf("%30c         {0O}  \n",nic);
    printf("%30c         \\__/   \n",nic);
    printf("%30c          \\^\\  \n",nic);
    printf("%30c           ) )  \n",nic);
    printf("%30c     _____/_/  \n",nic);
    printf("%30c    (_______)  \n",nic);
    printf("%30coO()_________)  \n",nic);
}
void gora()
{
    printf("%20c",nic);
    printf("OBRACAJ GRZECHOTNIKIEM NA ZMIANE\n");
    printf("%20c",nic);
    printf("1 - LEWO            2 - PRAWO\n");
}

void dol()
{
    printf("\n%25c",nic);
    for(int i=0;i<serce;i++)
    {
        printf("<3 ");    
    }
}
int main()
{   
    scanf("%d",&a);
    czysc();
        w=licz(a);
        printf("%50d",w);
        scanf("%d",&a);
        
    while(a!=0 && serce>0) //serce 0 oznacza utrate hp i wyjscie z petli
    {
        
        if(a==1)
            {
                czysc();
                w=licz(a);
                gora();
                wazprawy();
                printf("%25c",nic);
                printf("wynik: %10d\n",w);
                dol();
                while(a!=2)
                {
                scanf("%d",&a);
                    if(a!=2)
                        serce = serce -1;
                    else if(a==2)
                    {
                        czysc();
                        w=licz(a);
                        gora();
                        wazlewy();
                        printf("%25c",nic);
                        printf("wynik: %10d\n",w);
                        dol();
                    }
                }
            }
        else if(a==2)
            {
                czysc();
                w=licz(a);
                gora();
                wazlewy();
                printf("%25c",nic);
                printf("wynik: %10d\n",w);
                dol();
                while(a!=1)
                {
                scanf("%d",&a);
                    if(a!=1)
                        serce = serce -1;
                    else if(a==1)
                    {
                        czysc();
                        w=licz(a);
                        gora();
                        wazprawy();
                        printf("%25c",nic);
                        printf("wynik: %10d\n",w);
                        dol();
                    }
                }
            }
        scanf("%d",&a);
    }
    return 0;
}